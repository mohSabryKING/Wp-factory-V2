
      <!DOCTYPE html>
<html lang="en">
<head>
      <meta charset="UTF-8">
      <meta name="viewport" content="width=device-width',' initial-scale=1.0">
      <title>Document</title>
</head>
<header>
<?php get_header() ?>
</header>
<body>
<!--use-->
      <?php get_sidebar() ?>
      <!--or-->
<?php wp_nav_menu() ?>
      
      <section class="sec1"></section>
      <section class="sec2"></section>
      <section class="sec3"></section>
      <scricpt src='model.js'></script>
</body>
<footer>

<?php get_footer() ?>
</footer>
</html>
      